//
//  GameVariables.m
//  LetsSlot
//
//  Created by Tanut Apiwong on 9/2/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "GameVariables.h"

int mPaid;
int mBet;
int mCredit;
bool bSoundOn;
bool bPayoutLocked;