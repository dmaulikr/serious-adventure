RTQuiz
By Red Tempest Studios - http://www.redtempeststudios.com

Overview
========

RTQuiz is a simple, yet fun quiz game.  The default data for the quizzes is a collection of Spanish word lists.

Contact
=======

Web: http://www.redtempeststudios.com

License
=======

Copyright 2012 Red Tempest Studios All rights reserved.

RTQuiz is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RTQuiz is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser Public License for more details.

You should have received a copy of the GNU Lesser Public License
along with RTQuiz.  If not, see <http://www.gnu.org/licenses/>.