//
//  Quiz.m
//  RTQuiz
//
//  Created by Forthright Entertainment in 2013.
//  Copyright (c) 2013 Forthright Entertainment. All rights reserved.
//


#import "Quiz.h"
#import "Category.h"
#import "Element.h"


@implementation Quiz

@dynamic name;
@dynamic category;
@dynamic elements;

@end
