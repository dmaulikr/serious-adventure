//
//  Category.m
//  RTQuiz
//
//  Created by Forthright Entertainment in 2013.
//  Copyright (c) 2013 Forthright Entertainment. All rights reserved.
//


#import "Category.h"


@implementation Category

@dynamic difficulty;
@dynamic name;
@dynamic topic;
@dynamic scores;
@dynamic quizzes;

@end
