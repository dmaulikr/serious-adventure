//
//  Score.m
//  RTQuiz
//
//  Created by Forthright Entertainment in 2013.
//  Copyright (c) 2013 Forthright Entertainment. All rights reserved.
//


#import "Score.h"
#import "Category.h"


@implementation Score

@dynamic date;
@dynamic player;
@dynamic points;
@dynamic category;

@end
