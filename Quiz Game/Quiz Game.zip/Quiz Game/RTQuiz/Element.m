//
//  Element.m
//  RTQuiz
//
//  Created by Forthright Entertainment in 2013.
//  Copyright (c) 2013 Forthright Entertainment. All rights reserved.
//


#import "Element.h"


@implementation Element

@dynamic isBookmarked;
@dynamic isMastered;
@dynamic key;
@dynamic value;
@dynamic quiz;

@end
