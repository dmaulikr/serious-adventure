//
//  Topic.m
//  RTQuiz
//
//  Created by Forthright Entertainment in 2013.
//  Copyright (c) 2013 Forthright Entertainment. All rights reserved.
//


#import "Topic.h"
#import "Category.h"


@implementation Topic

@dynamic name;
@dynamic categories;

@end
